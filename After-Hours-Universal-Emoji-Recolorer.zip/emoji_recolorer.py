#!/usr/bin/env python3
"""
================================================================================
✨ UNIVERSAL DISCORD EMOJI RECOLORER & APPLICATION EMOJI UPLOADER
Created by T4N1SHQ | Support: https://discord.gg/n45bDCzgN3
================================================================================
Works with ANY Discord Bot (Python discord.py, JS/TS bots, or local image folders):
- Recolors Static PNG/WEBP and Animated GIF emojis frame-by-frame in HSV space
- Preserves alpha transparency, glow, shadows, white/grey/black highlights
- Supports targeting a specific source color (`red`, `blue`, `green`, `yellow`,
  `orange`, `purple`, `pink`, `cyan`, or `all` colored pixels)
- Supports ANY target color via Hex (`#9B59B6`, `#00FF88`, `#3B82F6`) or preset
  name (`purple`, `neon_purple`, `blue`, `cyan`, `green`, `gold`, `pink`, `red`, `orange`)
- Automatically uploads recolored emojis to your Discord Application Emojis and
  rewrites the old `<:name:id>` / `<a:name:id>` IDs in your bot files!
================================================================================
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import colorsys
import io
import os
import re
import sys
from typing import Dict, Iterable, List, Optional, Tuple

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

try:
    import aiohttp
except ImportError:
    print("✖ Missing dependency `aiohttp`. Install with: pip install aiohttp Pillow python-dotenv")
    sys.exit(1)

try:
    from PIL import Image, ImageSequence
except ImportError:
    print("✖ Missing dependency `Pillow`. Install with: pip install Pillow aiohttp python-dotenv")
    sys.exit(1)


# ── Named Target Color Presets (Hex -> RGB -> HSV) ───────────────────────────
COLOR_PRESETS: Dict[str, str] = {
    "purple": "#9B59B6",
    "neon_purple": "#A855F7",
    "violet": "#8B5CF6",
    "indigo": "#6366F1",
    "blue": "#3B82F6",
    "sky": "#0EA5E9",
    "cyan": "#06B6D4",
    "teal": "#14B8A6",
    "green": "#22C55E",
    "emerald": "#10B981",
    "lime": "#84CC16",
    "yellow": "#EAB308",
    "gold": "#F59E0B",
    "orange": "#F97316",
    "red": "#EF4444",
    "crimson": "#DC2626",
    "rose": "#F43F5E",
    "pink": "#EC4899",
    "magenta": "#D946EF",
    "white": "#FFFFFF",
}

# ── Source Hue Ranges (in degrees 0..360) for selective recoloring ───────────
SOURCE_HUE_RANGES: Dict[str, List[Tuple[float, float]]] = {
    "red": [(0.0, 28.0), (324.0, 360.0)],
    "orange": [(18.0, 48.0)],
    "yellow": [(45.0, 75.0)],
    "green": [(75.0, 165.0)],
    "cyan": [(165.0, 205.0)],
    "blue": [(200.0, 260.0)],
    "purple": [(255.0, 305.0)],
    "pink": [(295.0, 340.0)],
    "all": [(0.0, 360.0)],
}


def parse_target_color(color_str: str) -> Tuple[float, float, float]:
    """
    Parse a color preset name (e.g. 'purple') or Hex string (e.g. '#9B59B6')
    and return its HSV representation `(h, s, v)` where each value is in `0.0..1.0`.
    """
    raw = (color_str or "purple").strip().lower()
    hex_code = COLOR_PRESETS.get(raw, raw)
    hex_code = hex_code.lstrip("#")
    if len(hex_code) == 3:
        hex_code = "".join(ch * 2 for ch in hex_code)
    if len(hex_code) != 6 or not all(c in "0123456789abcdef" for c in hex_code):
        raise ValueError(
            f"Invalid color '{color_str}'. Use a hex code like '#9B59B6' or a preset: {', '.join(COLOR_PRESETS.keys())}"
        )
    r = int(hex_code[0:2], 16) / 255.0
    g = int(hex_code[2:4], 16) / 255.0
    b = int(hex_code[4:6], 16) / 255.0
    return colorsys.rgb_to_hsv(r, g, b)


def pixel_matches_source_color(r: int, g: int, b: int, a: int, from_color: str) -> Tuple[bool, float, float, float]:
    """
    Check if an RGBA pixel belongs to `from_color` (e.g., 'red', 'blue', 'all').
    Leaves transparent, white, grey, and black pixels untouched.
    """
    if a < 16:
        return False, 0.0, 0.0, 0.0
    rf, gf, bf = r / 255.0, g / 255.0, b / 255.0
    h, s, v = colorsys.rgb_to_hsv(rf, gf, bf)
    if s < 0.22 or v < 0.14:
        return False, h, s, v

    src = (from_color or "red").strip().lower()
    if src == "red" and r <= max(g, b) + 15:
        return False, h, s, v

    deg = (h * 360.0) % 360.0
    ranges = SOURCE_HUE_RANGES.get(src)
    if ranges is None:
        # User passed a custom hex color as --from-color
        th, _, _ = parse_target_color(src)
        tdeg = th * 360.0
        diff = abs(((deg - tdeg + 180.0) % 360.0) - 180.0)
        return (diff <= 28.0), h, s, v

    for low, high in ranges:
        if low <= deg <= high:
            return True, h, s, v
    return False, h, s, v


def recolor_frame(
    img: Image.Image,
    from_color: str = "red",
    to_color: str = "#9B59B6",
) -> Tuple[Image.Image, int]:
    """
    Recolor matching pixels in a single PIL Image frame from `from_color` to `to_color`.
    Returns `(recolored_rgba_image, changed_pixel_count)`.
    """
    target_h, target_s, target_v = parse_target_color(to_color)
    rgba = img.convert("RGBA")
    pixels = rgba.load()
    width, height = rgba.size
    changed = 0

    for y in range(height):
        for x in range(width):
            r, g, b, a = pixels[x, y]
            matched, h, s, v = pixel_matches_source_color(r, g, b, a, from_color)
            if not matched:
                continue
            changed += 1
            if target_s < 0.05:
                # Target is white / monochrome
                new_h = 0.0
                new_s = 0.0
                new_v = min(1.0, v * 1.15)
            else:
                new_h = target_h
                new_s = min(1.0, max(s, target_s * 0.85))
                new_v = min(1.0, v * 1.06)
            nr, ng, nb = colorsys.hsv_to_rgb(new_h, new_s, new_v)
            pixels[x, y] = (int(nr * 255), int(ng * 255), int(nb * 255), a)

    return rgba, changed


def recolor_emoji_bytes(
    image_bytes: bytes,
    *,
    from_color: str = "red",
    to_color: str = "#9B59B6",
    animated: bool = False,
    min_pixels: int = 15,
) -> Tuple[bytes, bool]:
    """
    Recolor a PNG, WEBP, or Animated GIF byte stream.
    Returns `(new_image_bytes, was_modified)`.
    """
    try:
        im = Image.open(io.BytesIO(image_bytes))
        if getattr(im, "is_animated", False) or animated:
            frames = []
            durations = []
            total_changed = 0
            for frame in ImageSequence.Iterator(im):
                dur = frame.info.get("duration", 50)
                rec_frame, cnt = recolor_frame(frame, from_color=from_color, to_color=to_color)
                total_changed += cnt
                frames.append(rec_frame)
                durations.append(dur)
            if total_changed < min_pixels:
                return image_bytes, False
            out = io.BytesIO()
            frames[0].save(
                out,
                format="GIF",
                save_all=True,
                append_images=frames[1:],
                loop=0,
                duration=durations,
                disposal=2,
            )
            return out.getvalue(), True
        else:
            rec_frame, cnt = recolor_frame(im, from_color=from_color, to_color=to_color)
            if cnt < min_pixels:
                return image_bytes, False
            out = io.BytesIO()
            rec_frame.save(out, format="PNG")
            return out.getvalue(), True
    except Exception:
        return image_bytes, False


class UniversalEmojiRecolorer:
    """
    Scans any bot's files for `<:name:id>` / `<a:name:id>` custom emojis,
    recolors matching emojis from `from_color` to `to_color`, uploads them to your
    Discord Application Emojis, and updates the IDs in your source files.
    """

    EMOJI_REGEX = re.compile(r"<(a?):([a-zA-Z0-9_]+):(\d+)>")

    def __init__(
        self,
        bot_or_token: object,
        *,
        from_color: str = "red",
        to_color: str = "#9B59B6",
        target_files: Optional[List[str]] = None,
        replace_existing: bool = True,
    ) -> None:
        self.bot_or_token = bot_or_token
        self.from_color = from_color
        self.to_color = to_color
        self.target_files = target_files or ["utils/emoji.py", "emoji.py", "src/emojis.json"]
        self.replace_existing = replace_existing

    async def _resolve_credentials(self, session: aiohttp.ClientSession) -> Tuple[Optional[str], Optional[str]]:
        if isinstance(self.bot_or_token, str):
            token = self.bot_or_token.strip()
            headers = {"Authorization": f"Bot {token}"}
            async with session.get("https://discord.com/api/v10/oauth2/applications/@me", headers=headers) as r:
                if r.status == 200:
                    data = await r.json()
                    return str(data.get("id")), token
            return None, token
        else:
            bot = self.bot_or_token
            if hasattr(bot, "wait_until_ready"):
                await bot.wait_until_ready()
            app_id = getattr(bot, "application_id", None)
            if not app_id and hasattr(bot, "application_info"):
                info = await bot.application_info()
                app_id = info.id
            token = getattr(getattr(bot, "http", None), "token", None) or os.getenv("BOT_TOKEN") or os.getenv("TOKEN") or os.getenv("DISCORD_TOKEN")
            return (str(app_id) if app_id else None), token

    async def run(self) -> int:
        existing_files = [f for f in self.target_files if os.path.isfile(f)]
        if not existing_files:
            print(f"✖ No target emoji files found among: {self.target_files}")
            return 0

        file_contents: Dict[str, str] = {}
        unique_emojis: Dict[str, Tuple[str, bool]] = {}

        for fp in existing_files:
            with open(fp, "r", encoding="utf-8") as f:
                txt = f.read()
            file_contents[fp] = txt
            for anim, name, eid in self.EMOJI_REGEX.findall(txt):
                if name not in unique_emojis:
                    unique_emojis[name] = (eid, bool(anim))

        if not unique_emojis:
            print("◈ No `<:name:id>` custom emojis found in target files.")
            return 0

        print(
            f"★ EmojiRecolorer: Found {len(unique_emojis)} unique emojis across {existing_files} "
            f"| Recoloring `{self.from_color}` -> `{self.to_color}`"
        )

        recolored_count = 0
        async with aiohttp.ClientSession() as session:
            app_id, token = await self._resolve_credentials(session)
            if not app_id or not token:
                print("✖ Could not authenticate with Discord API. Check your BOT_TOKEN.")
                return 0

            headers = {"Authorization": f"Bot {token}", "Content-Type": "application/json"}
            api_url = f"https://discord.com/api/v10/applications/{app_id}/emojis"

            async with session.get(api_url, headers=headers) as resp:
                items = (await resp.json()).get("items", []) if resp.status == 200 else []
            existing_map = {item["name"]: str(item["id"]) for item in items}

            for name, (old_id, is_animated) in unique_emojis.items():
                hosted_id = existing_map.get(name)
                ext = "gif" if is_animated else "png"
                img_data = None

                for cid in ([hosted_id, old_id] if hosted_id else [old_id]):
                    try:
                        async with session.get(f"https://cdn.discordapp.com/emojis/{cid}.{ext}") as r:
                            if r.status == 200:
                                img_data = await r.read()
                                break
                            elif is_animated:
                                async with session.get(f"https://cdn.discordapp.com/emojis/{cid}.png") as r2:
                                    if r2.status == 200:
                                        img_data = await r2.read()
                                        ext = "png"
                                        is_animated = False
                                        break
                    except Exception:
                        pass

                if not img_data:
                    continue

                new_bytes, was_modified = recolor_emoji_bytes(
                    img_data,
                    from_color=self.from_color,
                    to_color=self.to_color,
                    animated=is_animated,
                )

                if hosted_id and not was_modified:
                    # Already uploaded and doesn't match `from_color` — just sync ID
                    if hosted_id != old_id:
                        self._patch_files(file_contents, name, old_id, hosted_id, is_animated)
                    continue

                if hosted_id and was_modified and self.replace_existing:
                    try:
                        async with session.delete(f"{api_url}/{hosted_id}", headers=headers):
                            pass
                        await asyncio.sleep(0.8)
                    except Exception:
                        pass

                b64 = base64.b64encode(new_bytes).decode("utf-8")
                mime = "image/gif" if ext == "gif" else "image/png"
                payload = {"name": name, "image": f"data:{mime};base64,{b64}"}

                action_str = f"Recolored ({self.from_color} -> {self.to_color}) & Uploading" if was_modified else "Uploading"
                print(f"◈ {action_str}: {name}")

                async with session.post(api_url, headers=headers, json=payload) as post_resp:
                    if post_resp.status in (200, 201):
                        new_id = str((await post_resp.json())["id"])
                        print(f"✔ Uploaded {name} -> ID: {new_id}")
                        self._patch_files(file_contents, name, old_id, new_id, is_animated)
                        if was_modified:
                            recolored_count += 1
                    elif post_resp.status == 429:
                        wait_s = float((await post_resp.json()).get("retry_after", 3.0))
                        await asyncio.sleep(wait_s + 0.5)

                await asyncio.sleep(1.1)

        for fp, updated_txt in file_contents.items():
            with open(fp, "w", encoding="utf-8") as f:
                f.write(updated_txt)
        print(f"★ Done! Recolored & updated {recolored_count} emojis across {existing_files}.")
        return recolored_count

    @staticmethod
    def _patch_files(file_contents: Dict[str, str], name: str, old_id: str, new_id: str, is_animated: bool) -> None:
        prefix = "a" if is_animated else ""
        old_tag = f"<{prefix}:{name}:{old_id}>"
        new_tag = f"<{prefix}:{name}:{new_id}>"
        for fp in list(file_contents.keys()):
            file_contents[fp] = file_contents[fp].replace(old_tag, new_tag)


def recolor_local_folder(
    input_dir: str,
    output_dir: str,
    from_color: str = "red",
    to_color: str = "#9B59B6",
) -> int:
    """Recolor all .png, .gif, and .webp emoji files in a local folder."""
    os.makedirs(output_dir, exist_ok=True)
    count = 0
    for fn in sorted(os.listdir(input_dir)):
        if not fn.lower().endswith((".png", ".gif", ".webp")):
            continue
        src_p = os.path.join(input_dir, fn)
        dst_p = os.path.join(output_dir, fn)
        with open(src_p, "rb") as f:
            raw = f.read()
        is_gif = fn.lower().endswith(".gif")
        new_bytes, mod = recolor_emoji_bytes(raw, from_color=from_color, to_color=to_color, animated=is_gif, min_pixels=1)
        with open(dst_p, "wb") as f:
            f.write(new_bytes)
        if mod:
            count += 1
            print(f"✔ Recolored local file: {fn} -> {dst_p}")
    return count


async def sync_and_recolor_emojis(
    bot_or_token: object,
    from_color: str = "red",
    to_color: str = "#9B59B6",
    target_files: Optional[List[str]] = None,
) -> int:
    """Drop-in helper function for any discord.py bot's `on_ready()` or `setup_hook()`."""
    recolorer = UniversalEmojiRecolorer(
        bot_or_token,
        from_color=from_color,
        to_color=to_color,
        target_files=target_files,
    )
    return await recolorer.run()


def main() -> None:
    parser = argparse.ArgumentParser(description="Universal Discord Emoji Recolorer & Application Uploader")
    parser.add_argument("--token", default=os.getenv("BOT_TOKEN") or os.getenv("TOKEN") or os.getenv("DISCORD_TOKEN"), help="Discord Bot Token")
    parser.add_argument("--from-color", default=os.getenv("FROM_COLOR", "red"), help="Source color to replace: red, blue, green, yellow, orange, purple, pink, cyan, or all")
    parser.add_argument("--to-color", default=os.getenv("TO_COLOR", "#9B59B6"), help="Target color Hex (e.g. #9B59B6) or preset (purple, neon_purple, blue, cyan, green, gold, pink, red)")
    parser.add_argument("--files", nargs="*", default=None, help="Bot emoji files to scan & update (e.g. utils/emoji.py emojis.json)")
    parser.add_argument("--input-dir", default=None, help="Optional local folder of .png/.gif emojis to recolor offline")
    parser.add_argument("--output-dir", default="recolored_emojis", help="Output folder when using --input-dir")
    args = parser.parse_args()

    if args.input_dir:
        recolor_local_folder(args.input_dir, args.output_dir, from_color=args.from_color, to_color=args.to_color)
        return

    token = args.token
    if not token:
        print("── Interactive Emoji Recolorer Setup ──")
        token = input("Enter your Discord Bot Token: ").strip()
        from_c = input(f"Source color to replace [{args.from_color}]: ").strip() or args.from_color
        to_c = input(f"Target color Hex or Name [{args.to_color}]: ").strip() or args.to_color
        files_in = input("Emoji file path(s) comma-separated [utils/emoji.py,emoji.py]: ").strip()
        target_files = [x.strip() for x in files_in.split(",") if x.strip()] if files_in else None
    else:
        from_c = args.from_color
        to_c = args.to_color
        target_files = args.files
        if not target_files:
            env_files = os.getenv("TARGET_FILES", "")
            target_files = [x.strip() for x in env_files.split(",") if x.strip()] if env_files else None

    asyncio.run(sync_and_recolor_emojis(token, from_color=from_c, to_color=to_c, target_files=target_files))


if __name__ == "__main__":
    main()
